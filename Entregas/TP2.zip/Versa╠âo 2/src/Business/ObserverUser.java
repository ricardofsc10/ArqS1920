package Business;

public interface ObserverUser {
    void updatePrice(MarketStock mstk);
}

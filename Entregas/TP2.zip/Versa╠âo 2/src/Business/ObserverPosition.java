package Business;

public interface ObserverPosition {
    void updateBuy(MarketStock mstk);
    void updateSale(MarketStock mstk);
}

package Exceptions;

public class PasswordInvalidException extends Exception {
    public PasswordInvalidException(String s) {
    }
}

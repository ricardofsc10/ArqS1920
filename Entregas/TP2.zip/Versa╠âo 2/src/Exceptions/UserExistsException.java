package Exceptions;

public class UserExistsException extends Throwable {
    public UserExistsException(String s) {
    }
}

package Exceptions;

public class

StockNotExistsException extends Throwable {
}

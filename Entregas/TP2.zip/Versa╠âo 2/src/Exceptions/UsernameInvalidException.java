package Exceptions;

public class UsernameInvalidException extends Throwable {
    public UsernameInvalidException(String message) {
    }
}

package Exception;

public class PasswordIncorretaException extends Exception {
    public PasswordIncorretaException(String msg){
        super(msg);
    }
}

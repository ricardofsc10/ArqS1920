package Exception;

public class UtilizadorInexistenteException extends Exception {
    public UtilizadorInexistenteException(String msg){
        super(msg);
    }
}

package Exception;

public class StockExistenteException extends Exception {
    public StockExistenteException(String msg){super(msg);}
}
